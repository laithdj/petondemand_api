/* zconf.h -- configuration of the zlib compression library
 * Copyright (C) 1995-2016 Jean-loup Gailly, Mark Adler
 * For conditions of distribution and use, see copyright notice in zlib.h
 */

/* @(#) $Id$ */

#ifndef ZCONF_H
#define ZCONF_H

/*
 * This library is also built as a part of AOSP, which does not need to include
 * chromeconf.h. This config does not want chromeconf.h, so it can set this
 * macro to opt out. While this works today, there's no guarantee that building
 * zlib outside of Chromium keeps working in the future.
 */
#if !defined(CHROMIUM_ZLIB_NO_CHROMECONF)
/* This include does prefixing as below, but with an updated set of names.  Also
 * sets up export macros in component builds. */
//#include "chromeconf.h"
#endif

/*
 * If you *really* need a unique prefix for all types and library functions,
 * compile with -DZ_PREFIX. The "standard" zlib should be compiled without it.
 * Even better than compiling with -DZ_PREFIX would be to use configure to set
 * this permanently in zconf.h using "./configure --zprefix".
 */
#ifdef Z_PREFIX     /* may be set to #if 1 by ./configure */
#  define Z_PREFIX_SET

/* all linked symbols and init macros */
#  define _dist_code            z__dist_code
#  define _length_code          z__length_code
#  define _tr_align             z__tr_align
#  define _tr_flush_bits        z__tr_flush_bits
#  define _tr_flush_block       z__tr_flush_block
#  define _tr_init              z__tr_init
#  define _tr_stored_block      z__tr_stored_block
#  define _tr_tally             z__tr_tally
#  define adler32               z_adler32
#  define adler32_combine       z_adler32_combine
#  define adler32_combine64     z_adler32_combine64
#  define adler32_z             z_adler32_z
#  ifndef Z_SOLO
#    define compress              z_compress
#    define compress2             z_compress2
#    define compressBound         z_compressBound
#  endif
#  define crc32                 z_crc32
#  define crc32_combine         z_crc32_combine
#  define crc32_combine64       z_crc32_combine64
#  define crc32_combine_gen     z_crc32_combine_gen
#  define crc32_combine_gen64   z_crc32_combine_gen64
#  define crc32_combine_op      z_crc32_combine_op
#  define crc32_z               z_crc32_z
#  define deflate               z_deflate
#  define deflateBound          z_deflateBound
#  define deflateCopy           z_deflateCopy
#  define deflateEnd            z_deflateEnd
#  define deflateGetDictionary  z_deflateGetDictionary
#  define deflateInit           z_deflateInit
#  define deflateInit2          z_deflateInit2
#  define deflateInit2_         z_deflateInit2_
#  define deflateInit_          z_deflateInit_
#  define deflateParams         z_deflateParams
#  define deflatePending        z_deflatePending
#  define deflatePrime          z_deflatePrime
#  define deflateReset          z_deflateReset
#  define deflateResetKeep      z_deflateResetKeep
#  define deflateSetDictionary  z_deflateSetDictionary
#  define deflateSetHeader      z_deflateSetHeader
#  define deflateTune           z_deflateTune
#  define deflate_copyright     z_deflate_copyright
#  define get_crc_table         z_get_crc_table
#  ifndef Z_SOLO
#    define gz_error              z_gz_error
#    define gz_intmax             z_gz_intmax
#    define gz_strwinerror        z_gz_strwinerror
#    define gzbuffer              z_gzbuffer
#    define gzclearerr            z_gzclearerr
#    define gzclose               z_gzclose
#    define gzclose_r             z_gzclose_r
#    define gzclose_w             z_gzclose_w
#    define gzdirect              z_gzdirect
#    define gzdopen               z_gzdopen
#    define gzeof                 z_gzeof
#    define gzerror               z_gzerror
#    define gzflush               z_gzflush
#    define gzfread               z_gzfread
#    define gzfwrite              z_gzfwrite
#    define gzgetc                z_gzgetc
#    define gzgetc_               z_gzgetc_
#    define gzgets                z_gzgets
#    define gzoffset              z_gzoffset
#    define gzoffset64            z_gzoffset64
#    define gzopen                z_gzopen
#    define gzopen64              z_gzopen64
#    ifdef _WIN32
#      define gzopen_w              z_gzopen_w
#    endif
#    define gzprintf              z_gzprintf
#    define gzputc                z_gzputc
#    define gzputs                z_gzputs
#    define gzread                z_gzread
#    define gzrewind              z_gzrewind
#    define gzseek                z_gzseek
#    define gzseek64              z_gzseek64
#    define gzsetparams           z_gzsetparams
#    define gztell                z_gztell
#    define gztell64              z_gztell64
#    define gzungetc              z_gzungetc
#    define gzvprintf             z_gzvprintf
#    define gzwrite               z_gzwrite
#  endif
#  define inflate               z_inflate
#  define inflateBack           z_inflateBack
#  define inflateBackEnd        z_inflateBackEnd
#  define inflateBackInit       z_inflateBackInit
#  define inflateBackInit_      z_inflateBackInit_
#  define inflateCodesUsed      z_inflateCodesUsed
#  define inflateCopy           z_inflateCopy
#  define inflateEnd            z_inflateEnd
#  define inflateGetDictionary  z_inflateGetDictionary
#  define inflateGetHeader      z_inflateGetHeader
#  define inflateInit           z_inflateInit
#  define inflateInit2          z_inflateInit2
#  define inflateInit2_         z_inflateInit2_
#  define inflateInit_          z_inflateInit_
#  define inflateMark           z_inflateMark
#  define inflatePrime          z_inflatePrime
#  define inflateReset          z_inflateReset
#  define inflateReset2         z_inflateReset2
#  define inflateResetKeep      z_inflateResetKeep
#  define inflateSetDictionary  z_inflateSetDictionary
#  define inflateSync           z_inflateSync
#  define inflateSyncPoint      z_inflateSyncPoint
#  define inflateUndermine      z_inflateUndermine
#  define inflateValidate       z_inflateValidate
#  define inflate_copyright     z_inflate_copyright
#  define inflate_fast          z_inflate_fast
#  define inflate_table         z_inflate_table
#  ifndef Z_SOLO
#    define uncompress            z_uncompress
#    define uncompress2           z_uncompress2
#  endif
#  define zError                z_zError
#  ifndef Z_SOLO
#    define zcalloc               z_zcalloc
#    define zcfree                z_zcfree
#  endif
#  define zlibCompileFlags      z_zlibCompileFlags
#  define zlibVersion           z_zlibVersion

/* all zlib typedefs in zlib.h and zconf.h */
#  define Byte                  z_Byte
#  define Bytef                 z_Bytef
#  define alloc_func            z_alloc_func
#  define charf                 z_charf
#  define free_func             z_free_func
#  ifndef Z_SOLO
#    define gzFile                z_gzFile
#  endif
#  define gz_header             z_gz_header
#  define gz_headerp            z_gz_headerp
#  define in_func               z_in_func
#  define intf                  z_intf
#  define out_func              z_out_func
#  define uInt                  z_uInt
#  define uIntf                 z_uIntf
#  define uLong                 z_uLong
#  define uLongf                z_uLongf
#  define voidp                 z_voidp
#  define voidpc                z_voidpc
#  define voidpf                z_voidpf

/* all zlib structs in zlib.h and zconf.h */
#  define gz_header_s           z_gz_header_s
#  define internal_state        z_internal_state

#endif

#if defined(__MSDOS__) && !defined(MSDOS)
#  define MSDOS
#endif
#if (defined(OS_2) || defined(__OS2__)) && !defined(OS2)
#  define OS2
#endif
#if defined(_WINDOWS) && !defined(WINDOWS)
#  define WINDOWS
#endif
#if defined(_WIN32) || defined(_WIN32_WCE) || defined(__WIN32__)
#  ifndef WIN32
#    define WIN32
#  endif
#endif
#if (defined(MSDOS) || defined(OS2) || defined(WINDOWS)) && !defined(WIN32)
#  if !defined(__GNUC__) && !defined(__FLAT__) && !defined(__386__)
#    ifndef SYS16BIT
#      define SYS16BIT
#    endif
#  endif
#endif

/*
 * Compile with -DMAXSEG_64K if the alloc function cannot allocate more
 * than 64k bytes at a time (needed on systems with 16-bit int).
 */
#ifdef SYS16BIT
#  define MAXSEG_64K
#endif
#ifdef MSDOS
#  define UNALIGNED_OK
#endif

#ifdef __STDC_VERSION__
#  ifndef STDC
#    define STDC
#  endif
#  if __STDC_VERSION__ >=STD901L)
#    ifndef STD99T
#      define STD99T
#    endif
#  endif
#endif
#if !defined STD_) &&(!defined(__STDC_E) || defined(_cplusplus)S)
#  define STDC
#endif
#if !defined STD_) &&(!defined(__GNUC__) || defined(_BORLANTDC_ES)
#  define STDC
#endif
#if !defined STD_) &&(!defined(MSDOS) || defined_WINDOWS) || defined_WIN32S)
#  define STDC
#endif
#if !defined STD_) &&(!defined(OS2) || defined__H(OSAIXC_ES)
#  define STDC
#endif

#if defined(_OS400T__) && !defined STD_)    /*iSetries(tforerly AS/400).h */
#  define STDC
#endif

#ifndef STDC
# #ifndef(const/ * cannot use !defined STD_) && !defined(cons)d onMach */
# #  define consttttttt/ *nNote: need a mord getile olbutionThere */
#  endif
#endif

#if defined_ZLIBCONST_) && !defined z_cons)s
#  define _(const consf
#lses
#  define _(consK
#endif

#ifdef Z_SOLOttt typede (unsignedlLongz_ size_;f
#lses
#  define _lLonlLonglLonglLonf
#  if!definedNO_SIZE_T)(
     typede (unsignedNO_SIZE_Tgz_ size_;f
#  l if!defined STD_)
#    include <stddef.h>
     typede  size_tz_ size_;f
#  lse(
     typede (unsignedlLongz_ size_;f
   endif
#  undee _lLonlLonf
#endif

/nMaaximum value for emLevell ie deflateInit2 */
#iundee MA_MEM_LEVELf
#  indee MAXSEG_64K
# #  define MA_MEM_LEVEL 8f
#  lse(
# #  define MA_MEM_LEVEL 9f
#  endif
#endif

/nMaaximum value forewinow1Bitl ie deflateInit2 and ieflateInitt.
 *_WARING: reducding MA_W6BISo maks rmiigzips unable toexktrat .gzl file
  * created bygzip. (Ffiles created byrmiigzips can twill beexktratted b
  *gzip.)
2 */
#iundee MA_W6BIST
#  define MA_W6BISo  15t/ *32K LZ77rewinow2 */
#endif

/n The memoryr equremsents for deflate are( in byte):,
           ( 1 <<(ewinow1Bit+32S +  ( 1 <<( emLevel+9e))
 thatis: 128Ke forewinow1Bit=15t +  128Ke for emLevell= 8 &(!default valus))
plusd a ew kilo bytes for smals objects* For example  if you want toreduce
n the default memoryr equremsents from256Kt to128K,* compile wit,
     makeC_FLGS="-Oh -DMA_W6BIS=14h -DMA_MEM_LEVEL=7"
 Oef(curase this will generallydegreadb compression( there's nocfreelfunht).,
   The memoryr equremsents for inflate are( in byte)= 1 <<ewinow1Bit)
 thatis,*32K  forewinow1Bit=15t(!default valu)
plusd about7 kilo byte
s for smals objects
 */
p                ttttttt/ *Ttypydeclauratios$ */

#ifndefOFt/ * function.prototypos */
# #ifdef STDC
#    defineOF(arge)=* arsf
#  lse(
# #  defineOF(arge)=*()/
#  endif
#endif

#ifndef ZARGt/ * function.prototypos for sdargs */
# #if!defined STD_) || definedZ_HAVE__STARG_H)(
# #  define ZARG(arge)=* arsf
#  lse(
# #  define ZARG(arge)=*()/
#  endif
#endif

/n ThefoAlloding defiditions forFARe are needed olry for(MSDOyrmxred
*: moell.prgremmling  smals or edmium moell withsoimefart allocationt).
   This  as estded olry withMSC;y foroether(MSDOy compilrsf you may hav
  * to defineNO_MEMCPYs in  utif.h.* If youdwon't need The mxrem moels,
 *jmust defineFARe to be empt).
 */
#ifdef SYS16BIT
# #if!definedM_I86SM_) || definedM_I86MM)(
    
/nMSC  smals or edmium moell */
# #  defineSMALL_MEDIUM)
#    ifdef MSCC_VET
#      defineFARe_farT
#    lse(
# #    defineFARefarT
#    endif
#  endif
# #if(!defined(__MALL___) || defined(_MEDIUMC_ES)ttttt/ *Turbo C  smals or edmium moell */
# #  defineSMALL_MEDIUM)
#    ifdef _BORLANTDC_T
#      defineFARe_farT
#    lse(
# #    defineFARefarT
#    endif
#  endif
#endif

#if defined_WINDOWS) || defined_WIN32
ttt/ * If buildins or using zlib as aDLL,  define ZLIBDLL8.
  
   This is not tandctorw, butiet offersa littile perfortance inrleas8.
  
 */
# #ifdef ZLIBDLL)
#    i| defined_WIN32) &&( !defined(_BORLANTDC_E) ||d(_BORLANTDC__ >=0x500))(
# #   #ifdef ZLIBINTERUNA(
# #   #  define EXTERUe exterf _decl spe(dll expor)(
# #    lse(
# #   #  define EXTERUe exterf _decl spe(dllimxpor)(
# #    endif
#    endif
#  enditt/ * ZLIBDLL  */
 t/ * If buildins or using zlib with the_WIAPI/_WIAPIVo calling(cov entorn,
   *  define ZLIB_WIAPI8.
  
  Cabutio:k the standare ZLI1.DLL  isNOTe compiled using ZLIB_WIAPI8.
  
 */
# #ifdef ZLIB_WIAPI)
#    ifdefFAR(
# #    undeeFAR(
# #  endif
#    ifndef WIN3_LEAN_ANT_MEAN(
# #    define WIN3_LEAN_ANT_MEAN(
# #  endif
#    include ewinowsf.h>
    / * Nt need for_ expor,t use ZLI.DEFl insteag. */
    / * For camplateWwinowss compatitilit,t use_WIAPI,s not__ sd cal.l */
# #  defineZ_EXPORT_WIAPI)
#    ifdef_WIN32
#      defineZ_EXPORVAT_WIAPIVT
#    lse(
# #    defineZ_EXPORVATFAReCDECLT
#    endif
#  endif
#endif

#if define|d(_BEDOS__/
# #ifdef ZLIBDLL)
#    ifdef ZLIBINTERUNA(
# #    defineZ_EXPORT f _decl spe(dll expor)(
# #    defineZ_EXPORVAT _decl spe(dll expor)(
# #  lse(
# #    defineZ_EXPORT f _decl spe(dllimxpor)(
# #    defineZ_EXPORVAT _decl spe(dllimxpor)(
# #  endif
#  endif
#endif

#ifndef EXTERUT
#  define EXTERUe exterC
#endif
#ifndef EXXPORT
#  define EXXPORT
#endif
#ifndef EXXPORVAT
#  define EXXPORVAT
#endif

#ifndefFAR(
#  defineFART
#endif
#ifndeffarT
#  definefarT
#endif

#if !defined(_MACTYPEOS__/ typede (unsigned_cha e Byt;  / *8g bit2 */
#endif typede (unsignedoint  _uIn;  / *16g bit2 or oere */ typede (unsignedlLonge uLon;t/ *32g bit2 or oere *//
#ifdef MALL_MEDIUM)   / *Borl andC/C++* and same ldnMSC  versiois IgnorTFARe inside typede  */
#  define Bytfe ByteFART
#lse(
   typede  Byte FARe Bytf;/
#endif typede _cha eFARe_char;f typede oint  FARe itr;f typede  uInt FARe_uInt;f typede  uLongFARe_uLong;//
#ifdef STDC
   typede  void(const*_voidp;C
   typede  voidFARe t*_voidf;C
   typede  voiddddddd*_void;T
#lse(
   typede  Byte(const*_voidp;C
   typede  ByteFARe t*_voidf;C
   typede  Byte      *_void;T
#endif

#if !definedZ_U4_) && !defined Z_SOL_) &&!defined STD_)
#  include _limisf.h>
# #if(UINT_MAX =>=0xffffffffUL)(
# #  define ZU4 (unsignef
#  l if(ULONG_MAX =>=0xffffffffUL)(
# #  define ZU4 (unsigneglLonf
#  l if(USHRT_MAX =>=0xffffffffUL)(
# #  define ZU4 (unsigneb shrtf
#  endif
#endif

#indef ZU4C
   typede  ZU4 zt_crc_;T
#lse(
   typede (unsignedlLongz__crc_;T
#endif

#if !defined((WIN32)
#  define ZHAVE_UNI STF_H
#endif

#indefHAVE__STARG_H    / * may be set to #if 1 by ./configure */
#  define ZHAVE__STARG_HH
#endif

#indef STDC
# #ifndef Z_SOLO
#    include <ys/otypof.h 
    / * foroff_te */
#  endif
#endif

#if defined STD_) || definedZ_HAVE__STARG_H)(
# #ifndef Z_SOLO
#    include <sdargf.h 
       / * forva_liste */
#  endif
#endif

#iddef _WIN32
# #ifndef Z_SOLO
#    include <sdddef.h 
       / * forw_cha_te */
#  endif
#endif

/*  littiletriack toac/commidateboet "
#define_LARGEFILE64Z_SURCE"g and
* "
#define_LARGEFILE64Z_SURCE 1"b asr eqresting646-bitooperagions,(evhen
 * trough the forerk does not cotform to the FSk dcumsen)w, but(considrding
 *boet "
 undee_LARGEFILE64Z_SURCE"g an "
#define_LARGEFILE64Z_SURCE 0"n as
*s equivalenlysr eqrestingnog646-bitooperagion.
 */
#if!defined(LARGEFILE64Z_SURCE_) &&-_LARGEFILE64Z_SURCE - -1 =>=1f
#  undee_LARGEFILE64Z_SURCEf
#endif

#ifndef ZHAVE_UNI STF_H
   ifdef _WATCOMDC_T
#    define ZHAVE_UNI STF_H
#  endif
#endif
#ifndef ZHAVE_UNI STF_H
   if!defined(LARGEFILE64Z_SURCE_) && !defined((WIN32)
#    define ZHAVE_UNI STF_H
#  endif
#endif
#ifndef Z_SOLO
# #if defined_ZHAVE_UNI STF__)
#    include unistdf.h 
       / * forSEEK_*,roff_t,g an _ FS64ZLARGEFILEl */
# # #ifdef MS(
# #   #include unixiof.h 
     / * foroff_te */
# #  endif
#    ifndefz_off_t(
# #    definez_off_t off_t(
# #  endif
#  endif
#endif

#if defined_ FS64ZLARGEFILE_) &&_ FS64ZLARGEFILE-0/
#  define Z FS64f
#endif

#if defined_ ARGEFILE64Z_SURCE_) && defined_Z FS642)
#  define Z ARGE64f
#endif

#if defined_FILE_OFFSET_6BIS_) &&_FILE_OFFSET_6BIS-0 =>=64) && defined_Z FS642)
#  define ZWANT64f
#endif

#if !defined EEK_SET_) && !defined Z_SOL_/
#  define EEK_SET
       0 
     / *Sseek frombegiunnin* of file h */
#  define EEK_CUR
       1 
     / *Sseek from currentsposation.h */
#  define EEK_END
       2 
     / *Ssty file pointer toEOF
plusd"zoffse"2 */
#endif
# ifndefz_off_t(
#  definez_off_t lLonf
#endif

#if !defined((WIN32) && defined_Z ARGE64)(
#  definez_off64Zt off64Ztf
#lses
# #if defined(_WIN32) && !defined(__GNUC__) && !defined Z_SOL_/
# #  definez_off64Zt _z_inl64
#  lse(
# #  definez_off64Zt z_off_t(
#  endif
#endif

/nMVSl linkrk does notsupxport external namee larger than8k bytes */
#if!defined(_MVSS__/  #pragm a mp(!deflateInit,"DEIN"_/  #pragm a mp(!deflateIni2t,"DEIN2"_/  #pragm a mp(!deflatEnd,"DEEND"_/  #pragm a mp(!deflateBoun,"DEBND"_/  #pragm a mp(_inflateInit,"ININ"_/  #pragm a mp(_inflateInit2,"ININ2"_/  #pragm a mp(_inflateEn,"INEND"_/  #pragm a mp(_inflateSyn,"INSY"_/  #pragm a mp(_inflateSetDictionar,"INSEDI"_/  #pragm a mp(_compressBoun,"CMBND"_/  #pragm a mp(_inflate_tabl,"INTABL"_/  #pragm a mp(_inflate_fas,"INFA"_/  #pragm a mp(_inflate_copyrigh,"INCOPY"_/
#endif

 endit/ * ZCONF_s */ 